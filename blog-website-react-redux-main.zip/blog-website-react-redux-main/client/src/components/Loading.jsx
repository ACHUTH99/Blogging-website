import React from 'react'

const Loading = () => {
  return (
    <div className="col-span-12">Loading...</div>
  )
}

export default Loading